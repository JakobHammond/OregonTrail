import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
/**
 * @Author Anthony Parker
 * @FileName baseMenu.java
 * @Date 5/10/24
 * Description: a menu that can put the required components for the trade display onto a frame.
 */
public class tradeMenu extends Menu {
	private JTextArea inventoryArea = new JTextArea();
	private JLabel tradePicLabel = new JLabel("");
	private JTextPane tradeOutputPane = new JTextPane();
	private JButton acceptButton = new JButton("Accept");
	private JButton exitButton = new JButton("Exit");
	private JButton newTradeButton = new JButton("New Trade");
	public tradeMenu(JFrame frame) {
		super(frame);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * displays the trade components onto the objects frame
	 * @param wagon - the wagon that you are displaying to
	 * @param nextFrame - the frame you'ld like to be displayed when this frame is exited
	 * @param trade - the trade object the wagon is trading with
	 */
	public void Display(Wagon wagon, JFrame nextFrame, Trade trade) {
		
		trade.setRandTrade();
		
		
		inventoryArea.setBounds(6, 6, 173, 288);
		frame.getContentPane().add(inventoryArea);
		ArrayList<Item> inventory = wagon.getInventory();
		String inventoryString = "";
		for(Item item: inventory) {
			inventoryString = inventoryString + item.getName() + "\n";
		}
		inventoryArea.setText(inventoryString);
		
		
		tradePicLabel.setBounds(203, 6, 435, 263);
		frame.getContentPane().add(tradePicLabel);
		
		
		tradeOutputPane.setBounds(203, 292, 435, 68);
		frame.getContentPane().add(tradeOutputPane);
		tradeOutputPane.setText("You got offered " +trade.getOffer()+ " For " + trade.getRequest());
		
	
		acceptButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (trade.tradeWithWagon(wagon)) {
					tradeOutputPane.setText("Succesfull trade");
					ArrayList<Item> inventory = wagon.getInventory();
					String inventoryString = "";
					for(Item item: inventory) {
						inventoryString = inventoryString + item.getName() + "\n";
					}
					inventoryArea.setText(inventoryString);
				}
				else tradeOutputPane.setText("Didn't have required item, failed to trade");
			}
		});
		acceptButton.setBounds(203, 372, 117, 29);
		frame.getContentPane().add(acceptButton);
		
		
		exitButton.setBounds(677, 423, 117, 29);
		frame.getContentPane().add(exitButton);
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				nextFrame.setVisible(true);
			}
		});
		
	
		newTradeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				trade.setRandTrade();
				tradeOutputPane.setText("You got offered " +trade.getOffer()+ " For " + trade.getRequest());
			}
		});
		newTradeButton.setBounds(521, 372, 117, 29);
		frame.getContentPane().add(newTradeButton);
	}

}
