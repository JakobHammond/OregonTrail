import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

/**
* @Author Anthony Parker
* @FileName LandmarkMenu.java
* @Date 5/10/24
* Description: a menu that can put the required components for the landmark display onto a frame.
*/
public class LandmarkMenu extends Menu {
	private JLabel locationLabel;
	private JTextArea conversationArea = new JTextArea();
	private JButton shopButton = new JButton("Go to Shop");
	private JButton riverButton = new JButton("Try to cross River");
	private JButton exitButton = new JButton("Back to the Trail");
	
	public LandmarkMenu(JFrame frame) {
		super(frame);
		locationLabel = new JLabel();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * puts the required objects and actionListeners onto a specified frame 
	 * @param locations - the array of locations you are traveling along
	 * @param shopFrame - the frame that contains a shop display
	 * @param riverFrame - the frame that you'ld like to contain a rivers display
	 * @param baseFrame - the frame that contains the base display
	 * @param riverMenu - the menu that can display a specified river
	 * @param wagon - the wagon that you're traveling along the trail with
	 */
	public void Display (ArrayList<Landmark> locations, JFrame shopFrame, JFrame riverFrame, JFrame baseFrame, RiverMenu riverMenu, Wagon wagon ) {

		
		conversationArea.setBounds(63, 330, 590, 118);
		frame.getContentPane().add(conversationArea); 
		
		JButton conversationButton = new JButton("Talk with folks");
		conversationButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String conversation = "";
				File file = new File(locations.get(0).getName()+".txt"); //gets the conversation associated with a landmark
				try {
					Scanner in = new Scanner(file);
					while(in.hasNextLine()) {
						String str = in.nextLine();
						conversation+=str;
					}
					in.close();
				}
				catch (IOException a) {
					System.out.println("No file found");
				}
				conversationArea.setText(conversation);
			}
		});
		conversationButton.setBounds(222, 129, 233, 29);
		frame.getContentPane().add(conversationButton);
		
		
		
		shopButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				shopFrame.setVisible(true); //exits to shop frame
				frame.setVisible(false);
				locations.remove(0);
			}
		});
		shopButton.setBounds(222, 199, 233, 29);
		frame.getContentPane().add(shopButton);
		if (locations.get(0) instanceof Fort) shopButton.setVisible(true);
		else shopButton.setVisible(false);
		
		
		riverButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (locations.get(0) instanceof River) {
					riverMenu.Display((River)locations.get(0),baseFrame,wagon); // displays specified river into riverDisplay
					riverFrame.setVisible(true);
					frame.setVisible(false);
					locations.remove(0);
				}
			}
		});
		riverButton.setBounds(222, 272, 233, 29);
		frame.getContentPane().add(riverButton);
		if (locations.get(0) instanceof River)  riverButton.setVisible(true);
		else riverButton.setVisible(false);
		
		
		locationLabel.setText("Welcome to " + locations.get(0).getName() );
		locationLabel.setHorizontalAlignment(SwingConstants.CENTER);
		locationLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		locationLabel.setBounds(127, 50, 433, 51);
		frame.getContentPane().add(locationLabel);
		
		
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				baseFrame.setVisible(true); //exits to base frame
				frame.setVisible(false);
				locations.remove(0);
			}
		});
		exitButton.setBounds(222, 342, 233, 29);
		frame.getContentPane().add(exitButton);
	}
}
