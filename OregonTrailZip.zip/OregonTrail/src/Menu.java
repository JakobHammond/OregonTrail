/**
 * @author Anthony Parker
 * @FileName Menu.java
 * @Date 5/10/24
 * the parent function of the rest of the menu displaying classes
 */

import javax.swing.JFrame;


public class Menu {
	protected JFrame frame;
	
	/**
	 * the frame utilized to display contents onto
	 * @param frame - the frame you'ld like to display contents onto
	 */
	public Menu(JFrame frame) {
		this.frame = frame;
	}
	
	/**
	 * gets the frame you are displaying onto
	 * @return the frame you are displaying onto
	 */
	public JFrame getFrame() {
		return frame;
	}
	
	public void Display() {

	}
}

