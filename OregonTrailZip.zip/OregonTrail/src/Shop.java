/**
 * @FileName: Shop.java
 * @Author: Anthony Parker
 * @Date: 4/17/24
 * Description: generates a shop for an Oregon trail game which has an array list of items that represents the "Stock" of the shop, 
 * this Stock can be purchased from, also displays this shop in a given Frame.
 */



import java.util.ArrayList;


public class Shop {
	private ArrayList<Item> Stock;
	private double priceMultiplier; //to increase prices as you travel to further forts 
	
	/**
	 * Constructor that loads shop with an array Stock
	 *@param Stock - the list of items you want the shop to contain
	 */
	public Shop(ArrayList<Item> Stock) {
		priceMultiplier=1;
		this.Stock = Stock;
	}
	/**
	 * gives the available items from the shop
	 * @return a list of items available at the shop
	 */
	public ArrayList<Item> getStock(){
		return Stock;
	}
	/**
	 * returns the priceMultiplier
	 * @return a double value that represents how much more expensive the prices are then their base price.
	 */
	public double getPriceMultiplier() {
		return priceMultiplier;
	}

}
