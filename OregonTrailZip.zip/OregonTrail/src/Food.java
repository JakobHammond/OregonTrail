/**
 * @author Anthony Parker
 * @FileName Food.java
 * @Date 5/10/24
 * an item of edible food, that can be partially consumed, and holds a name price and weight.
 */
public class Food extends Item {

	/**
	 * constructor for the food class
	 * @param weight - the weight of the food item
	 * @param basePrice - the price of the food item
	 * @param name - the name of the food item
	 */
	public Food(int weight, double basePrice, String name) {
		super(weight, basePrice, name);
	}

	/**
	 * consumes a portion of the food item's weight
	 * @param amountNeeded - the amount of food you'ld liek to consume
	 */
	public void eatFood (int amountNeeded) {
		int n = this.getWeight();
		n -= amountNeeded;
		this.setWeight(n);
	}
	
	/**
	 * checks to see if this food item has a greater weight than the amount needed
	 * @param amountNeeded - the amount of food required
	 * @return true if food has enough weight, false otherwise
	 */
	public boolean isEnoughFood (int amountNeeded) {
		if (amountNeeded > this.getWeight()) return false;
		else return true;
	}

}
