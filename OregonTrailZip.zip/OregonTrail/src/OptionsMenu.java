import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.JTextArea;

/**
* @Author Anthony Parker
* @FileName OptionsMenu.java
* @Date 5/10/24
* Description: a menu that can put the required components for the options display onto a frame.
*/
public class OptionsMenu extends Menu {
	private JTextArea inventoryArea = new JTextArea();
	private JLabel paceLabel = new JLabel("Pace:");
	private JSlider paceSlider = new JSlider();
	private JLabel slowPaceLabel = new JLabel("Slow");
	private JLabel mediumPaceLabel = new JLabel("Moderate");
	private JLabel fastPaceLabel = new JLabel("Grueling");
	private JSlider rationSlider = new JSlider();
	private JLabel bareBoneLabel = new JLabel("Bare Bones");
	private JLabel meagerLabel = new JLabel("Meager");
	private JLabel fillingLabel = new JLabel("Filling");
	private JLabel rationLabel = new JLabel("Rations:");
	private JButton continueButton = new JButton("Continue on Trail");
	private JButton tradeButton = new JButton("Attempt to trade");
	/**
	 * Constructor for OptionsMenu
	 * @param frame - the frame you'ld like to display an options menu onto
	 */
	public OptionsMenu(JFrame frame) {
		super(frame);
	}
	
	/**
	 * Displays the options, such a changing pace and rations
	 * @param wagon - the wagon you are displaying for
	 * @param baseFrame - the frame holding base display
	 * @param tradeFrame - the frame holding trade display
	 */
	public void Display(Wagon wagon, JFrame baseFrame, JFrame tradeFrame, tradeMenu tradeMenu, Trade trade) {
		
		
		paceSlider.setMajorTickSpacing(1);
		paceSlider.setValue((wagon.getPace()/10)-1);
		paceSlider.setPaintTicks(true);
		paceSlider.setSnapToTicks(true);
		paceSlider.setMinorTickSpacing(1);
		paceSlider.setMinimum(1);
		paceSlider.setMaximum(3);
		paceSlider.setBounds(55, 6, 190, 29);
		paceLabel.setBounds(17, 6, 61, 16);
		slowPaceLabel.setBounds(55, 47, 61, 16);
		mediumPaceLabel.setBounds(121, 47, 61, 16);
		fastPaceLabel.setBounds(204, 47, 61, 16);
		rationSlider.setValue(wagon.getRations());
		rationSlider.setSnapToTicks(true);
		rationSlider.setPaintTicks(true);
		rationSlider.setMinorTickSpacing(1);
		rationSlider.setMinimum(1);
		rationSlider.setMaximum(3);
		rationSlider.setMajorTickSpacing(1);
		rationSlider.setBounds(75, 122, 190, 29);	
		bareBoneLabel.setBounds(44, 163, 72, 16);
		meagerLabel.setBounds(149, 163, 61, 16);
		fillingLabel.setBounds(231, 163, 61, 16);
		rationLabel.setBounds(6, 122, 61, 16);
		continueButton.setBounds(491, 435, 200, 29);
		tradeButton.setBounds(17, 435, 193, 29);		
		inventoryArea.setBounds(437, 47, 224, 350);
		
		// puts the inventory and party into a single string to be displayed into a text area
		ArrayList<Item> inventory = wagon.getInventory();
		String inventoryString = "Inventory: \n";
		for(Item item: inventory) {
			inventoryString = inventoryString + item.getName() +  "(" + item.getWeight() + "lb) " + "\n";
		}
		inventoryString = inventoryString + "\n Party: \n";
		for (Passenger person: wagon.getParty()) {
			inventoryString = inventoryString + person.getName() + "\n";
		}
		inventoryArea.setText(inventoryString);
		
		frame.getContentPane().add(tradeButton);
		tradeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tradeMenu.Display(wagon, frame, trade);
				frame.setVisible(false);
				tradeFrame.setVisible(true);
			}});
		
		frame.getContentPane().add(continueButton);
		continueButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				wagon.setPace(paceSlider.getValue());
				wagon.setRations(rationSlider.getValue());
				baseFrame.setVisible(true);
				frame.setVisible(false);

			}});
		
		frame.getContentPane().add(fillingLabel);
		frame.getContentPane().add(meagerLabel);
		frame.getContentPane().add(bareBoneLabel);
		frame.getContentPane().add(rationSlider);
		frame.getContentPane().add(fastPaceLabel);
		frame.getContentPane().add(mediumPaceLabel);
		frame.getContentPane().add(slowPaceLabel);
		frame.getContentPane().add(paceLabel);
		frame.getContentPane().add(paceSlider);
		frame.getContentPane().add(rationLabel);
		frame.getContentPane().add(inventoryArea);		
	}
}
