import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 * @Author Anthony Parker
 * @FileName baseMenu.java
 * @Date 5/10/24
 * Description: a menu that can put the required components for the river display onto a frame.
 */
public class RiverMenu extends Menu {
	private JLabel riverPicLabel = new JLabel("");
	private JButton fordButton = new JButton("Ford");
	private JButton ferryButton = new JButton("Ferry");
	private	JButton floatButton = new JButton("Float");
	private JLabel costLabel = new JLabel("cost: 20");
	private	JLabel moneyLabel = new JLabel();
	private JTextArea riverInfoArea = new JTextArea();
	
	public RiverMenu(JFrame frame) {
		super(frame);
		// TODO Auto-generated constructor stub
	}
	/**
	 * displays the river onto the objects associated frame
	 * @param river - the river you are displaying
	 * @param nextFrame - the frame that follows this frames displaying
	 * @param wagon - the wagon traveling along the trail
	 */
	public void Display (River river, JFrame nextFrame, Wagon wagon) {
		ImageIcon image = new ImageIcon("/Images/River-1.png.png");
		
		riverPicLabel.setBounds(159, 6, 494, 279);
		riverPicLabel.setIcon(image);
		riverPicLabel.setOpaque(true);
		frame.getContentPane().add(riverPicLabel);
		
		riverInfoArea.setBounds(90, 350, 590, 118);
		riverInfoArea.setText(river.riverInfo());
		frame.getContentPane().add(riverInfoArea); 
		
	
		fordButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean check = river.didCrossRiver("ford", wagon);
				if (check) {
					JOptionPane.showMessageDialog(null, "you successfully crossed the river","Success",JOptionPane.INFORMATION_MESSAGE);
					frame.setVisible(false);
					nextFrame.setVisible(true);
				}
				else {
					JOptionPane.showMessageDialog(null, "you sank while trying to cross the river, you lost some items","failure",JOptionPane.INFORMATION_MESSAGE);
					frame.setVisible(false);
					nextFrame.setVisible(true);
				}
			}
		});
		fordButton.setBounds(147, 309, 117, 29);
		frame.getContentPane().add(fordButton);
		
		
		ferryButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean check = river.didCrossRiver("ferry", wagon);
				if (check) {
					JOptionPane.showMessageDialog(null, "you successfully crossed the river","Success",JOptionPane.INFORMATION_MESSAGE);
					frame.setVisible(false);
					nextFrame.setVisible(true);
				}
				else {
					JOptionPane.showMessageDialog(null, "you sank while trying to cross the river, you lost some items","failure",JOptionPane.INFORMATION_MESSAGE);
					frame.setVisible(false);
					nextFrame.setVisible(true);
				}
			}
		});
		ferryButton.setBounds(335, 309, 117, 29);
		frame.getContentPane().add(ferryButton);
		
	
		floatButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean check = river.didCrossRiver("float", wagon);
				if (check) {
					JOptionPane.showMessageDialog(null, "you successfully crossed the river","Success",JOptionPane.INFORMATION_MESSAGE);
					frame.setVisible(false);
					nextFrame.setVisible(true);
				}
				else {
					JOptionPane.showMessageDialog(null, "you sank while trying to cross the river, you lost some items","failure",JOptionPane.INFORMATION_MESSAGE);
					frame.setVisible(false);
					nextFrame.setVisible(true);
				}
			}
		});
		floatButton.setBounds(536, 309, 117, 29);
		frame.getContentPane().add(floatButton);
		
		
		costLabel.setBounds(360, 336, 61, 16);
		frame.getContentPane().add(costLabel);
		
	
		moneyLabel.setText("Money: " + wagon.getMoney());
		moneyLabel.setBounds(17, 430, 220, 16);
		frame.getContentPane().add(moneyLabel);
	}
	

}
