

/**
 * @Author Anthony Parker
 * @FileName Item.java
 * @Date 5/10/24
 * Item class stores an Item with a specified weight
 */
public class Item {
	
	private int weight;
	private double basePrice;
	private String name;
	
	/**
	 * the constructor for the item class
	 * @param weight the weight of the Item
	 * @param isFood true if the Item is food, false otherwise
	 */
	public Item(int weight, double basePrice, String name) {
		// TODO Auto-generated constructor stub
		this.weight=weight;
		this.basePrice=basePrice;
		this.name=name;
		
	}
	
	/**
	 * returns the weight of the item
	 * @return the weight of the item
	 */
	public int getWeight() {
		return weight;
	}
	
	/**
	 * sets the weight of the item to a specified n
	 * @param n - integer value to set weight to
	 */
	public void setWeight(int n) {
		weight = n;
	}
	
	/** 
	 * returns the base price of the item
	 * @return the base price of the item
	 */
	public double getBasePrice() {
		return basePrice;
	}
	
	/**
	 * gives the name of the Item
	 * @return the name of the Item
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * checks to see if two items have the same name
	 * @param otherItem - the item you'ld like to compare to
	 * @return true if they have the same name, false otherwise
	 */
	public boolean equals (Item otherItem) {
		if (otherItem.getName()==name) return true;
		else return false;
	}


}
