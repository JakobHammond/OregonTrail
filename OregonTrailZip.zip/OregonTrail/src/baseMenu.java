import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
/**
 * @Author Anthony Parker
 * @FileName baseMenu.java
 * @Date 5/10/24
 * Description: a menu that can put the required components for the base display onto a frame.
 */
public class baseMenu extends Menu {
	private JLabel trailPicLabel = new JLabel();
	private ImageIcon image = new ImageIcon(getClass().getResource("OregonTrailClearWeatherOx-1.png.png"));
	private JButton menuButton = new JButton("Options");
	private JLabel dayLabel = new JLabel("Days: ");
	private JLabel healthLabel = new JLabel("Health: ");
	private JLabel foodLabel = new JLabel("Food Left: ");
	private JLabel weatherLabel = new JLabel();
	private JLabel milesToLabel = new JLabel();
	private JLabel milesTraveledLabel = new JLabel();
	private JLabel eventLabel = new JLabel();
	private JButton landmarkButton = new JButton();
	private JButton nextDayButton = new JButton("Travel Day");
	private JButton restDayButton = new JButton("Rest Day");
	
	/**
	 * the constructor for the baseMenu
	 * @param frame - the frame you'ld like the menmu to put it's contents onto
	 */
	public baseMenu(JFrame frame) {
		super(frame);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * displays the contents of the base display onto the frame
	 * @param locations - the arrayList of locations
	 * @param endMenu - the menu that displays the ending screen
	 * @param endFrame - the frame that contains the ending screen menu's display
	 * @param landmarkFrame - the frame that contains the landmark screen display
	 * @param optionsFrame - the frame that contains the options screen display
	 * @param wagon - the main wagon that travels along the trail
	 * @param weather - the weather along the trail
	 * @param optionsMenu - the menu that displays the options screen
	 * @param tradeFrame - the frame that contains the trade screen display
	 */
	public void Display(tradeMenu tradeMenu, Trade trade, JFrame shopFrame,JFrame riverFrame, RiverMenu riverMenu, LandmarkMenu landmarkMenu, ArrayList<Landmark> locations, endMenu endMenu, JFrame endFrame, JFrame landmarkFrame, JFrame optionsFrame, Wagon wagon, Weather weather, OptionsMenu optionsMenu, JFrame tradeFrame) {
		
		trailPicLabel.setBounds(152, 6, 539, 360);
		
		
		trailPicLabel.setIcon(image);
		trailPicLabel.setOpaque(true);
		
		
		menuButton.setBounds(23, 400, 117, 29);
		RandomEvents randomEvent = new RandomEvents();
		menuButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				optionsMenu.Display(wagon,optionsFrame,tradeFrame,tradeMenu,trade); //updates options display
				optionsFrame.setVisible(true);
				frame.setVisible(false);
			}
			
		});
		
		
		
		dayLabel.setBounds(6, 6, 300, 16);
		dayLabel.setText("Day: "+ wagon.getDay());
		healthLabel.setBounds(6, 34, 300, 16);
		healthLabel.setText("Health: "+wagon.getGroupHealth());
		
		foodLabel.setText("Food Left: "+wagon.getFoodLeft());
		foodLabel.setBounds(6, 62, 300, 100);
		
		weatherLabel.setText("Weather: "+weather.getCurrentTemp()+" and " + weather.getCurrentWeather());
		weatherLabel.setBounds(6, 90,300, 16);
		
		milesToLabel.setText("Miles to " + locations.get(0).getName() + ":" + (locations.get(0).getLocation()-wagon.getDistance()));
		milesToLabel.setBounds(6, 118, 300, 16);
		
		milesTraveledLabel.setText("Miles Traveled: " + wagon.getDistance());
		milesTraveledLabel.setBounds(6, 138, 300, 16);
		
		eventLabel.setBounds(6, 287, 1000, 16);
		frame.getContentPane().add(eventLabel);
		
				
		landmarkButton.setBounds(251, 400, 247, 29);
		landmarkButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				landmarkFrame.setVisible(true);
				frame.setVisible(false);
			}
			
		});
		landmarkButton.setVisible(false);
		
		
		nextDayButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				weather.WeatherDay();
				wagon.travelDay(weather);
				
				if (wagon.isPartyDead()) { //changes to end screen if player has lost
					endMenu.Display(false);
					endFrame.setVisible(true); 
					frame.setVisible(false);
				}
				
				
				randomEvent.setEvents(weather, wagon);
				Random rand = new Random();
				int i = rand.nextInt(10);
				if (i>5) {
					randomEvent.eventHappens(wagon, weather);
					eventLabel.setText(randomEvent.getEventString());
				}
				

				if(wagon.getDistance()>locations.get(0).getLocation()) {
					if (locations.get(0).getName() == "End of the Trail") {
						endMenu.Display(true);
						endFrame.setVisible(true);
						frame.setVisible(false);
					}
					else {
						if (locations.get(0) instanceof River) {
							riverMenu.Display((River)locations.get(0), frame, wagon);
							landmarkFrame.setVisible(true);
							frame.setVisible(false);
						}
						landmarkButton.setText("go to " + locations.get(0).getName());
						landmarkMenu.Display(locations,shopFrame,riverFrame,frame,riverMenu,wagon);
						landmarkButton.setVisible(true);
						wagon.setDistance(locations.get(0).getLocation());
						
					}
				}
				else landmarkButton.setVisible(false);
				
				dayLabel.setText("Days: "+wagon.getDay());
				healthLabel.setText("Health: "+wagon.getGroupHealth());	
				foodLabel.setText("Food Left: "+wagon.getFoodLeft());
				weatherLabel.setText("Weather: "+weather.getCurrentTemp()+" and " + weather.getCurrentWeather());
				milesToLabel.setText("Miles to " + locations.get(0).getName() + ": " + (locations.get(0).getLocation()-wagon.getDistance()));
				milesTraveledLabel.setText("Miles Traveled: " + wagon.getDistance());
				
				

			}
		});
		nextDayButton.setBounds(558, 6, 117, 29);
		frame.getContentPane().add(nextDayButton);
		
		
		
		restDayButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				wagon.restDay(1);
				weather.WeatherDay();
				
				
				dayLabel.setText("Days: "+wagon.getDay());
				healthLabel.setText("Health: "+wagon.getGroupHealth());	
				foodLabel.setText("Food Left: "+wagon.getFoodLeft());
				weatherLabel.setText("Weather: "+weather.getCurrentTemp()+" and " + weather.getCurrentWeather());
				milesToLabel.setText("Miles to " +	locations.get(0).getName() + ":" + (locations.get(0).getLocation()-wagon.getDistance()));
				milesTraveledLabel.setText("Miles Traveled: " + wagon.getDistance());
			}
		});
		restDayButton.setBounds(400, 6, 117, 29);
		frame.getContentPane().add(restDayButton);


		
		
		frame.getContentPane().add(milesTraveledLabel);
		frame.getContentPane().add(milesToLabel);
		frame.getContentPane().add(weatherLabel);
		frame.getContentPane().add(foodLabel);
		frame.getContentPane().add(healthLabel);
		frame.getContentPane().add(dayLabel);
		frame.getContentPane().add(trailPicLabel);
		frame.getContentPane().add(menuButton);
		frame.getContentPane().add(landmarkButton); 
	}

}
