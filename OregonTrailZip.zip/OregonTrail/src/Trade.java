
/**
 * @FileName Trade.java
 * @Author Grace Conrad
 * @Date 4/17/24
 * Description: A trade that can be carried out between an NPC and the "wagon" which represents the player
 */

import java.util.ArrayList;
import java.util.Random;

public class Trade {
	
	private ArrayList<Item> potentialTrades;
	private Item offer;
	private Item request;
	
	/**
	 * Constructor that gives a small amount of items for potential trades, for demo purposes only
	 */
	public Trade(ArrayList<Item> availableItems) {
		potentialTrades = availableItems;
	}
	
	/**
	 * set's the current offered item and requested items to random items from the potentialTrades ArrayList
	 */
	public void setRandTrade() {
		Random rand = new Random();
		int n = rand.nextInt(potentialTrades.size());
		offer = potentialTrades.get(n);
		
		n = rand.nextInt(potentialTrades.size());
		request = potentialTrades.get(n);
	}
	
	/**
	 * actually carries out the trade if possible, returning whether or not the trade occurred
	 * @param wagon - the wagon the trade is occurring with
	 * @return true if a trade was possible and occurred and false otherwise.
	 */
	public boolean tradeWithWagon(Wagon wagon) {
		
		boolean check = false;
		for (Item i: wagon.getInventory()) {
			if(i.getName().equals(request.getName())) check = true;
		}
		if (check) {
			wagon.addItem(offer);
			for (Item i: wagon.getInventory()) {
				if(i.getName().equals(request.getName())) {
					wagon.removeItem(i);
					break;
				}
			}
			return true;
		}
		else return false;
	}
	
	/**
	 * gets the offered items name
	 * @return a string containing the offered items name
	 */
	public String getOffer() {
		return offer.getName();
	}
	/**
	 * gets the requested items name
	 * @return a string that contains the requested items name
	 */
	public String getRequest() {
		return request.getName();
	}
	

		
	

}
	