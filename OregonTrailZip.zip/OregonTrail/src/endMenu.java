import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
/**
* @Author Anthony Parker
* @FileName endMenu.java
* @Date 5/10/24
* Description: a menu that can put the required components for the end display onto a frame.
*/
public class endMenu extends Menu {

	public endMenu(JFrame frame) {
		super(frame);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * puts all the labels required for the end frame, based on if you won or if you lost
	 * @param didWin - true if you did win, false otherwise
	 */
	public void Display(boolean didWin) {
		JLabel deadLabel = new JLabel("Y");
		deadLabel.setHorizontalAlignment(SwingConstants.CENTER);
		deadLabel.setFont(new Font("Academy Engraved LET", Font.PLAIN, 44));
		deadLabel.setBounds(236, 17, 236, 72);
		frame.getContentPane().add(deadLabel);
		
		JLabel deadPicLabel = new JLabel("");
		deadPicLabel.setBounds(0, 0, 800, 534);
		deadPicLabel.setOpaque(true);
		
		if (didWin) {
			deadLabel.setText("You Won");
			ImageIcon image = new ImageIcon ("/Images/OregonTrailStart.png");
			deadLabel.setIcon(image);
		}
		else {
			deadLabel.setText("You Lost");
			ImageIcon image = new ImageIcon ("/Images/Death-1.png.png");
		}
		frame.getContentPane().add(deadPicLabel);
	}
}
