

/**
 * @author Jakob Hammond
 * @FileName Landmark.java
 * @Date 5/10/24
 * a landmark with an associated distance from the start of the trail and a name
 */
public class Landmark {
	int location;
	String name;
	
	/**
	 * implicit constructor of landmark
	 */
	public Landmark() {
	}
	
	/**
	 * constructor for Landmark
	 * @param lmName - the name of the landmark
	 * @param lmLocation - the distance from the start of the trail
	 */
	public Landmark(String lmName, int lmLocation) {
		name = lmName;
		location = lmLocation;	
	}
	/**
	 * gives the distance from the start of the trail
	 * @return the location of the landmark
	 */
	public int getLocation() {
		return location;
	}
	
	/**
	 * returns the name of the landmark
	 * @return the name of the landmark
	 */
	public String getName() {
		return name;
	}
	
	
}
