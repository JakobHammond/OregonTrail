import java.util.Random;
/**
 * @author Anthony Parker
 * @FileName Weather.jave
 * @Date 5/10/24
 * simulates the weather, giving a temperature and weather condition.
 */
public class Weather {
	private double accumulatedRain;
	private double accumulatedSnow;
	private String currentWeather;
	private String currentTemp;
	
	/**
	 * The constructor for the weather class, gives a little rain accumulated initially so that you aren't immediately in a drought.
	 */
	public Weather() {
		accumulatedRain = 1;
		accumulatedSnow = 0;
		this.newCurrentTemp();
		this.newCurrentWeather();
	}
	
	/**
	 * sets a new temperature as the current temperature
	 */
	public void newCurrentTemp() {
		int avgTemp = 51;
		Random rand = new Random();
		int actualTemp = rand.nextInt(avgTemp-25,avgTemp+26);
		if(actualTemp>90) currentTemp = "Very Hot";
		else if (actualTemp>70) currentTemp = "Hot";
		else if (actualTemp>50) currentTemp = "Warm";
		else if (actualTemp>30) currentTemp = "Cool";
		else if (actualTemp>10) currentTemp = "Cold";
		else currentTemp = "Very Cold";
	}
	/**
	 * sets a new weather as the current weather
	 */
	public void newCurrentWeather() {
		
		double avgRainfall = 3.5; 
		Random rand = new Random();
		if (rand.nextDouble(10)<avgRainfall) {
			if(currentTemp=="Cold"||currentTemp=="Very Cold") {
				if(rand.nextInt(10)<3) currentWeather = "Heavy Snow";
				else currentWeather = "Light Snow";
			}
			else {
				if(rand.nextInt(10)<3) currentWeather = "Heavy Rain";
				else currentWeather = "Light Rain";
			}
		}
		else currentWeather = "Clear";
	}
	
	/**
	 * gets the current temperature as a string
	 * @return very hot to very cold
	 */
	public String getCurrentTemp() {
		return currentTemp;
	}
	/**
	 * gets the current weather as a string
	 * @return from heavy rain to drought, the current weather as a string
	 */
	public String getCurrentWeather() {
		return currentWeather;
	}
	/**
	 * gives the amount of rain accumulated on the ground
	 * @return the amount of rain accumulated in inches
	 */
	public double getAccumulatedRain() {
		return accumulatedRain;
	}
	/**
	 * randomly generates whether or not new weather will appear then generates new weather if it does, also adds accumulated rain and snow.
	 */
	public void WeatherDay() {
		Random rand = new Random();
		if(rand.nextInt()<5) {
			this.newCurrentWeather();
			this.newCurrentTemp();
		}
		if (currentWeather == "Light Rain") accumulatedRain+=.2;
		else if (currentWeather == "Heavy Rain") accumulatedRain+=.8;
		else if (currentWeather == "Heavy Snow") accumulatedSnow+=8;
		else if (currentWeather == "Light Snow") accumulatedSnow+=2;
		else {
			if(accumulatedRain>0)accumulatedRain-=(.01*accumulatedRain);
			if(accumulatedSnow>0) {
				if(currentTemp == "Very Hot"||currentTemp == "Hot"|| currentTemp == "Warm") {
					accumulatedSnow-=5;
					accumulatedRain += .5;
					if(accumulatedSnow<0) accumulatedSnow = 0;
				}
				else accumulatedSnow-=(.03*accumulatedSnow);
				}
			}
		if(accumulatedRain < .1) currentWeather = "Severe Drought";
		else if (accumulatedRain < .2) currentWeather = "Drought";
		}


}
