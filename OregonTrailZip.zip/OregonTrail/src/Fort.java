
/**
 * @Author Jakob Hammond
 * @FileName Fort.java
 * @Date 5/10/24
 * a fort landmark that allows us to check if certain landmark is a fort and if so displaying a shop.
 */
public class Fort extends Landmark {
	private String name;
	private int location;

	
	/**
	 * the constructor of fort
	 * @param name - the name of the fort
	 * @param location - tho location of the fort
	 */
	public Fort(String name, int location) {
		this.name = name;
		this.location = location;
	}
	
	
	/**
	 * gives the distance from the start of the fort
	 * @return the location of the fort
	 */
	public int getLocation() {
		return location;
	}
	
	/**
	 * gives the name of the fort
	 * @return -the name of the fort
	 */
	public String getName() {
		return name;
	}
}
