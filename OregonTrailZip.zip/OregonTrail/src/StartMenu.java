import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
/**
 * @Author Anthony Parker
 * @FileName StartMenu.java
 * @Date 5/10/24
 * Description: a menu that can put the required components for the start display onto a frame.
 */
public class StartMenu extends Menu {

	public StartMenu(JFrame frame) {
		super(frame);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * puts the contents of the starting frame onto the objects frame
	 * @param nextFrame - the frame that is meant to follow the starting frame
	 */
	public void Display (JFrame nextFrame) {
		
		
	ImageIcon image = new ImageIcon(getClass().getResource("/Images/OregonTrailStart.png"));
		
		JLabel titleLabel = new JLabel("Oregon Trail");
		titleLabel.setFont(new Font("Academy Engraved LET", Font.PLAIN, 50));
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		titleLabel.setBounds(0, 0, 800, 100);
		frame.getContentPane().add(titleLabel);
		JButton startButton = new JButton("Start");
		startButton.setBounds(325,230,150,50);
		frame.getContentPane().add(startButton);
		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				nextFrame.setVisible(true);
			}
			
		});		
		JLabel startPicLabel = new JLabel("");
		startPicLabel.setBounds(0, 0, 800, 534);
		frame.getContentPane().add(startPicLabel);
		startPicLabel.setIcon(image);
	}

}
