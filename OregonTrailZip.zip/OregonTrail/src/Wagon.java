

import java.util.ArrayList;
import java.util.Random;

/**
 * @author Anthony Parker
 * file: Wagon.java
 * date:4/9/2024
 * wagon class that can track how far it has traveled it's pace, the rations each person gets, the Food available, the Resources held
 * the health of the group the number of people, and how much money the wagon has.a
 * it will act as an inventory for our final Oregon trail game.
 */
public class Wagon {
	
	private ArrayList<Item> inventory;
	private ArrayList<Passenger> party;
	private int groupHealth; //increases to indicate poor health
	private final int MAXWEIGHT = 2400;
	private int weight;
	private int distanceTraveled;
	private int pace;
	private int rationLevel;
	private double money;
	private int days;
	
	/**
	 * constructor for wagon, creates a wagon with empty inventory and basic party
	 */
	public Wagon() {
		inventory = new ArrayList<Item>();
		party = new ArrayList<Passenger>();
		Passenger person1 = new Passenger("John");
		Passenger person2 = new Passenger("Shelly");
		Passenger person3 = new Passenger("Mark");
		Passenger person4 = new Passenger("Barbra");
		party.add(person1);
		party.add(person2);
		party.add(person3);
		party.add(person4);
		
		pace=20;
		rationLevel=3;
		money=500;
		weight=0;
		groupHealth=0;
		days=0;
		distanceTraveled=0;
	}
	
	/**
	 * adds a specified item to the wagons inventory
	 */
	public void addItem(Item item) {
			inventory.add(item);
			weight=weight+item.getWeight();
	}
	
	/**
	 * returns a list of the party members
	 * @return the array list of party members
	 */
	public ArrayList<Passenger> getParty(){
		return party;
	}
	
	/**
	 * checks to see if an item will put wagon over maximum weight
	 * @param item - the item you'ld like to check
	 * @return true if item will put wagon overweight, false otherwise
	 */
	public boolean doesGoOverweight(Item item) {
		if (weight + item.getWeight() > MAXWEIGHT) return true;
		else return false;
	}
	
	/**
	 * removes a specified item from the wagon's inventory 
	 * @param item - the item you'ld like to remove from wagon's inventory
	 */
	public void removeItem(Item item) {
		
		inventory.remove(item);
		weight=weight-item.getWeight();
	}
	
	/** 
	 * simulates the wagon resting for n days
	 * @param n- the amount of days being rested
	 */
	public void restDay(int n) {
		for(int i =0; i<n; i++) {
		if (this.hasFoodLeft()) {
			applyFoodEffects(party.size()*rationLevel);
			groupHealth -= 6;
		}
		else groupHealth += 4;
		
		days++;
	}
	}
	
	
	/**
	 * apply's the appropriate effects to show a wagon traveling a day, adding distance, subtracting food, applying effects on health
	 * @param weather - the weather along the trail
	 */
	public void travelDay(Weather weather) {
				
			
		
			if (this.hasFoodLeft()) applyFoodEffects(party.size()*rationLevel);
		
		
			applyHealthEffects(weather);
			distanceTraveled=distanceTraveled+pace;
			days++;
	}
	
	/**
	 * consumes an amount of food based on how much is needed
	 * @param foodAmountNeeded - the amount of food needed
	 */
	public void applyFoodEffects(int foodAmountNeeded) {
		if(foodAmountNeeded>this.getFoodLeft()) {
			
		}
		else {
			while (foodAmountNeeded>0) {
					Food foodItem = this.getFoodItem();
				if (foodItem.getWeight() > foodAmountNeeded){
					foodItem.eatFood(foodAmountNeeded);
					foodAmountNeeded = 0;
				}
				else if (foodItem.getWeight() == foodAmountNeeded) {
					this.removeItem(foodItem);
					foodAmountNeeded = 0;
				}
				else {
					foodAmountNeeded -= foodItem.getWeight();
					this.removeItem(foodItem);
				}
			}
		}
	}
	
	/**
	 * applies the health effects of having low rations, no food, or extremely poor health
	 * @param weather - the weather along the trail
	 */
	public void applyHealthEffects(Weather weather) {
		if(this.getFoodLeft()==0) groupHealth+=6;
		else if (rationLevel==2) groupHealth+=2;
		else if (rationLevel==1) groupHealth+=4;
		
		if (weather.getCurrentWeather() == "Drought") groupHealth += 3;
		else if (weather.getCurrentWeather() == "Severe Drought") groupHealth += 5;
		
		if(pace==20) groupHealth+=2;
		else if (pace==30) groupHealth+=4;
		else if (pace==40) groupHealth+=6;
	
		if(groupHealth>=140) {
			int healthCheckNum = -1;
			int deathIndex = 0;
			for (int i =0; i<party.size(); i++) {
				if (party.get(i).getHealthLevel()>healthCheckNum) {
					healthCheckNum = party.get(i).getHealthLevel();
					deathIndex = i;
				}
			}
			party.remove(deathIndex);
		}
	}
	
	/**
	 * get's the distance the wagon has traveled so far
	 * @return the distance the wagon has traveled
	 */
	public int getDistance() {
		return distanceTraveled;
	}
	
	public int getFoodLeft() {
		int foodWeight = 0;
		for (Item item : inventory) {
			if (item instanceof Food) foodWeight += item.getWeight(); 
		}
		return foodWeight;
	}

	
	/**
	 * get's the amount of money had in the wagon
	 * @return the current amount of money in the wagon
	 */
	public double getMoney() {
		return money;
	}
	
	/**
	 * for stores, essentially add item but also subtracts a price from the total amount of money the wagon has.
	 * @param item - the item you'ld like to purchase
	 * @param d - the price of the item
	 */
	public void buyItem (Item item, double d) {
		money-=d;
		this.addItem(item);
	}
	
	/**
	 * removes an amount of money from the wagon
	 * @param amount - the amount of money to remove
	 */
	public void removeMoney (double amount) {
		money-=amount;
	}
	
	/**
	 * get's the groups health as a string from dying to good
	 * @return a string describing the current group health
	 */
	public String getGroupHealth() {
		if(groupHealth<=34) return "Good";
		else if(groupHealth<=65) return "Fair";
		else if(groupHealth<=104) return "Poor";
		else if(groupHealth<=139) return "Very Poor";
		else return "Dying";
	}
	
	/**
	 * sets the pace of the wagon
	 * @param pace - a value 1-3 that shows the pace you travel a day
	 */
	public void setPace(int pace) {
		if(pace==1) this.pace=20;
		if(pace==2) this.pace=30;
		if(pace==3) this.pace=40;
	}
	
	/**
	 * set's the amount of food that each person on the wagon will get
	 * @param rationLevel - a value 1-3 that describes how much food each person is eating a day
	 */
	public void setRations(int rationLevel) {
		this.rationLevel=rationLevel;
	}
	/**
	 * gives the current ration level of the wagon
	 * @return the current ration level of the wagon.
	 */
	public int getRations() {
		return rationLevel;
	}
	
	/**
	 * get's the pace at which the wagon is traveling
	 * @return the pace at which the wagon is traveling
	 */
	public int getPace() {
		return pace;
	}
	
	/**
	 * get's the amount of days the wagon has been traveling
	 * @return the amount of days the wagon has been traveling
	 */
	public int getDay() {
		return days;
	}
	
	/**
	 * gives the complete inventory of the wagon
	 * @return the inventory list from the wagon
	 */
	public ArrayList<Item> getInventory(){
		return inventory;
	}
	
	/**
	 * gives the topmost food item in the inventory
	 * @return the first found food item in the wagons inventory
	 */
	public Food getFoodItem() {
		for (Item item : inventory) {
			if (item instanceof Food) return (Food) item;
		}
		return null;
	}
	
	/**
	 * gives the current weight of the wagon
	 * @return - the current weight of the wagon
	 */
	public int getWeight() {
		return weight;
	}
	
	/**
	 * determines if the wagon has food left
	 * @return true if the wagon has food left, false otherwise
	 */
	public boolean hasFoodLeft() {
		if (this.getFoodLeft() > 0) return true;
		else return false;
	}
	
	/**
	 * tests if the player has lost or not
	 * @return true if all party members have died, false otherwise
	 */
	public boolean isPartyDead() {
		if(party.isEmpty()) return true;
		else return false;
	}
	
	/**
	 * sets the distance the wagon has traveled to a certain value
	 * @param distance - the distance you'ld like the wagon to travel
	 */
	public void setDistance(int distance) {
		distanceTraveled = distance;
	}
	

	
	/**
	 * gets a random item from the wagons inventory
	 * @return a random item from the wagons inventory
	 */
	public Item getRandomItem() {
		Random rnd = new Random();
		if (!inventory.isEmpty()) {
			int i = rnd.nextInt(inventory.size());
			return inventory.get(i);
		}
		else return null;
	}

	/**
	 * gets a random passenger from the wagon
	 * @return a random passenger from the wagon
	 */
	public Passenger getRandomPassenger() {
		Random rnd = new Random();
		int i = rnd.nextInt(party.size());
		return party.get(i);
	}

}
