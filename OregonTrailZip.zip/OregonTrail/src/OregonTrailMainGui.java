/**
 * @author Anthony Parker
 * @FileName OregonTrailMainGui.java
 * @Date 5/10/24
 * the primary display of the Oregon trail game
 */
import java.awt.EventQueue;
import java.util.ArrayList;
import javax.swing.JFrame;


public class OregonTrailMainGui {

	private JFrame baseFrame;
	private JFrame shopFrame;
	private JFrame landmarkFrame;
	private JFrame riverFrame;
	private JFrame startFrame;
	private JFrame tradeFrame;
	private JFrame optionsFrame;
	private JFrame endFrame;
	private baseMenu baseMenu;
	private ShopMenu shopMenu;
	private tradeMenu tradeMenu;
	private StartMenu startMenu;
	private OptionsMenu optionsMenu;
	private RiverMenu riverMenu;
	private LandmarkMenu landmarkMenu;
	private endMenu endMenu;
	private Shop shop;
	private Trade trade;
	private Wagon wagon = new Wagon();
	private Weather weather = new Weather();
	private ArrayList<Landmark> locations;
	private ArrayList<Item> availableItems;
	
	
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OregonTrailMainGui window = new OregonTrailMainGui();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public OregonTrailMainGui() {
		
		wagon = new Wagon();
		weather = new Weather();
		//Generating all locations and putting them into the locations list
				 Fort fortWallaWalla = new Fort("Fort Walla Walla", 350);
				 Landmark blueMountains = new Landmark("Blue Mountains", 2100);
			     Fort fortBridger = new Fort("Fort Bridger", 1500);
			     Landmark independenceRock = new Landmark("Independence Rock", 1000);
			     Landmark southPass = new Landmark("South Pass", 1200);
			     Fort fortLaramie = new Fort("Fort Laramie", 800);
			     Landmark theDalles = new Landmark("The Dalles", 2500);
			     River bigBlueRiver = new River("Big Blue River", 200, 5.0, 40.0);
			     River greenRiver = new River("Green River", 2000, 6.0, 50.0);
			     River snakeRiver = new River("Snake River", 1100, 7.0, 60.0);
			     Landmark endOfTrail = new Landmark("End of the Trail",2900);
			     
			     locations = new ArrayList<Landmark>();
			     locations.add(bigBlueRiver);
			     locations.add(fortWallaWalla);
			     locations.add(fortLaramie);
			     locations.add(independenceRock);
			     locations.add(snakeRiver);
			     locations.add(southPass);
			     locations.add(fortBridger);
			     locations.add(greenRiver);
			     locations.add(blueMountains);
			     locations.add(theDalles);
			     locations.add(endOfTrail);
			   //Generating all the items and putting them into available items  
			     Food bacon = new Food(200, 20, "Bacon");
			     Food flour = new Food(100, 10, "Flour");
			     Food cornmeal = new Food(100, 8, "Cornmeal");
			     Food rice = new Food(100, 10, "Rice");
			     Food beans = new Food(100, 12, "Beans");
			     Food saltPork = new Food(200, 25, "Salt Pork");
			     Food beef = new Food(200, 35, "Beef");
			     Item boots = new Item(1, 10, "Boots");
			     Item shoes = new Item(1, 5, "Shoes");
			     Item pants = new Item(1, 5, "Pants");
			     Item dresses = new Item(1, 5, "Dresses");
			     Item shirts = new Item(1, 2, "Shirts");
			     Item ammunition = new Item(20, 2, "Ammunition");
			     Item wagonWheel = new Item(1, 100, "Wagon Wheel");
			     Item sparePartsKit = new Item(1, 200, "Spare Parts Kit");
			     Item fishingPole = new Item(1, 2, "Fishing Pole");
			     Item rifle = new Item(1, 60, "Rifle");
			     Item pistol = new Item(1, 59, "Pistol");
			     Item firstAidKit = new Item(1, 5, "First Aid Kit");
			     
			     availableItems = new ArrayList<Item>();
			     availableItems.add(bacon);
			     availableItems.add(flour);
			     availableItems.add(cornmeal);
			     availableItems.add(rice);
			     availableItems.add(beans);
			     availableItems.add(saltPork);
			     availableItems.add(shoes);
			     availableItems.add(shirts);
			     availableItems.add(ammunition);
			     availableItems.add(wagonWheel);
			     availableItems.add(firstAidKit);
			     
			     shop = new Shop(availableItems);
			     trade = new Trade(availableItems);
			     
			     
				
		initialize(); // builds the frames
		//makes menus for each frame
		optionsMenu = new OptionsMenu(optionsFrame);
		shopMenu = new ShopMenu(shopFrame);
		baseMenu = new baseMenu(baseFrame);
		startMenu = new StartMenu(startFrame);
		landmarkMenu = new LandmarkMenu(landmarkFrame);
		riverMenu = new RiverMenu(riverFrame);
		tradeMenu = new tradeMenu(tradeFrame);
		endMenu = new endMenu(endFrame);
		//displays menus onto each frame
		baseMenu.Display(tradeMenu, trade, shopFrame, riverFrame, riverMenu, landmarkMenu, locations, endMenu, endFrame,landmarkFrame,optionsFrame,wagon,weather,optionsMenu,tradeFrame);
		shopMenu.Display(shop,wagon,landmarkFrame,baseFrame,false);
		startMenu.Display(shopFrame);
		optionsMenu.Display(wagon,baseFrame,tradeFrame, tradeMenu, trade);
		landmarkMenu.Display(locations,shopFrame,riverFrame,baseFrame,riverMenu,wagon);
		tradeMenu.Display(wagon,baseFrame,trade);
		startFrame.setVisible(true);
		
		
		
		
		

		
		
		//start display
		//display shop
		//then start on trail
		
		
		
}
	
	
	
	
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		baseFrame = new JFrame();
		baseFrame.setBounds(100, 100, 800, 534);
		baseFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		baseFrame.getContentPane().setLayout(null);
						
		startFrame = new JFrame();
		startFrame.setBounds(100, 100, 800, 534);
		startFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		startFrame.getContentPane().setLayout(null);
		
		shopFrame = new JFrame();
		shopFrame.setBounds(100, 100, 800, 534);
		shopFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		shopFrame.getContentPane().setLayout(null);
		
		optionsFrame = new JFrame();
		optionsFrame.setBounds(100, 100, 800, 534);
		optionsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		optionsFrame.getContentPane().setLayout(null);
		
		landmarkFrame = new JFrame();
		landmarkFrame.setBounds(100, 100, 800, 534);
		landmarkFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		landmarkFrame.getContentPane().setLayout(null);
		
		riverFrame = new JFrame();
		riverFrame.setBounds(100, 100, 800, 534);
		riverFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		riverFrame.getContentPane().setLayout(null);
		
		tradeFrame = new JFrame();
		tradeFrame.setBounds(100, 100, 800, 534);
		tradeFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		tradeFrame.getContentPane().setLayout(null);
		
		endFrame = new JFrame();
		endFrame.setBounds(100, 100, 800, 534);
		endFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		endFrame.getContentPane().setLayout(null);
	
		
		
	
	
		
		/**
		 * base travel display w/ miles traveled, current weather, date, food left, group health, and miles to next location shown
		 * have listener to bring up a menu where you can see your inventory, change pace, change food rations, choose to rest for a day, 
		 * or choose to trade, if trade is chosen bring up trade display
		 * Start day Loop:
		 * check to ensure party isn't dead and that wagon is capable of moving.
		 * move one day, with all health effects
		 * check weather
		 * update displays to give current information
		 * if has lost bring up losing display, else ignore this
		 * check to see if at a location:
		 * if at a location prompt player to interact with location:
		 * if location is a fort give choice of conversation or shop
		 * if location is a river give choice of conversation or attempt to cross river
		 * otherwise location is just a spot for conversation and trading
		 * if not at a location or once location is left loop the days every couple of seconds
		 */
		
	}
}
