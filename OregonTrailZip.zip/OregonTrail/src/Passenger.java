/**
 * @Author Max Williams
 * @FileName Passenger.java
 * @Date 5/10/24
 * a passenger on the wagon you are traveling on the trail with
 */
public class Passenger {
	private String name;
	private int healthLevel;
	
	/**
	 * constructor for the passenger class
	 * @param name the name of the passenger
	 */
	public Passenger(String name) {
		this.name=name;
		healthLevel=0;
	}
	
	/** 
	 * adds a certain amount of bad health to the healthLevel
	 * @param damage the amount you are adding to healthLevel
	 */
	public void addBadEffect(int damage) {
		healthLevel+=damage;
	}
	
	/**
	 * return the amount of bad health built up
	 * @return the health level
	 */
	public int getHealthLevel() {
		return healthLevel;
	}
	
	/**
	 * gives the name of the passenger
	 * @return the name of the passenger as a string
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * tests to see if two passenger objects have the same name
	 * @param otherPassenger the passenger you are comparing with
	 * @return true if they have the same name, false otherwise
	 */
	public boolean equals (Passenger otherPassenger) {
		if (otherPassenger.getName()==name) return true;
		else return false;
	}
}
